'use strict';

const { Clutter, Gio, GObject, St } = imports.gi;

const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;
const SystemActions = imports.misc.systemActions;

// Lance une commande externe sans bloquer ; renvoie true si le processus a pu demarrer.
function _trySpawn(argv) {
    try {
        Gio.Subprocess.new(argv, Gio.SubprocessFlags.NONE);
        return true;
    } catch (e) {
        return false;
    }
}

function _lock() {
    // 1) Action interne de GNOME (GDM / la plupart des sessions)
    const sysActions = SystemActions.getDefault();
    if (sysActions.canLockScreen) {
        sysActions.activateLockScreen();
        return;
    }

    // 2) LightDM (cas Ubuntu/LightDM : 'dm-tool lock')
    if (_trySpawn(['dm-tool', 'lock']))
        return;

    // 3) Repli systemd-logind
    _trySpawn(['loginctl', 'lock-session']);
}

const LockScreenButton = GObject.registerClass(
class LockScreenButton extends PanelMenu.Button {
    _init() {
        super._init(0.0, 'Lock Screen Button', true);

        this.add_child(new St.Icon({
            icon_name: 'changes-prevent-symbolic',
            style_class: 'system-status-icon',
        }));

        this.connect('button-press-event', this._onClicked.bind(this));
        this.connect('touch-event', this._onClicked.bind(this));
    }

    _onClicked() {
        _lock();
        return Clutter.EVENT_STOP;
    }
});

let _button = null;

function init() {
}

function enable() {
    _button = new LockScreenButton();
    Main.panel.addToStatusArea('lockscreen-button', _button, 0, 'right');
}

function disable() {
    if (_button !== null) {
        _button.destroy();
        _button = null;
    }
}
